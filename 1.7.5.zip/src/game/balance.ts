export type Lang = 'en' | 'pt';
export type ChassisId = 'interceptor' | 'guardiao' | 'tesla' | 'sombra';
export type CardCategory = 'weapon' | 'passive' | 'tactical';
export type Rarity = 'common' | 'rare' | 'epic' | 'evo';

export interface ChassisPalette {
    main: string;
    dark: string;
    light: string;
    visor: string;
    visorGlow: string;
    accent: string;
}

export interface ChassisDef {
    id: ChassisId;
    name: string;
    cost: number;
    medalsReq: number;
    hpMult: number;
    dmgMult: number;
    spdMult: number;
    armor: number;
    crit: number;
    chain: number;
    empMult: number;
    descPt: string;
    descEn: string;
    pal: ChassisPalette;
}

export interface LabUpgradeDef {
    id: 'hull' | 'weapon' | 'capacitor' | 'engine' | 'magnet' | 'empCore' | 'salvage';
    namePt: string;
    nameEn: string;
    descPt: string;
    descEn: string;
    baseCost: number;
    growth: number;
    maxLv: number;
}

export interface HangarState {
    kills: number;
    tanks: number;
    bestWave: number;
    bestTime: number;
    bestLevel: number;
    scrap: number;
    ach: Record<string, number>;
    chassis: ChassisId;
    unlockedChassis: Record<string, boolean>;
    lab: Record<string, number>;
    goldSkinActive: boolean;
}

export interface PlayerStats {
    x: number;
    y: number;
    r: number;
    chassis: ChassisId;
    spd: number;
    maxHp: number;
    hp: number;
    inv: number;
    aim: number;
    dmg: number;
    baseRate: number;
    rate: number;
    fireT: number;
    range: number;
    mag: number;
    lv: number;
    xp: number;
    maxXp: number;
    spreadLv: number;
    orbits: number;
    orbitA: number;
    pierce: number;
    chain: number;
    chainCD: number;
    missiles: number;
    missileT: number;
    wingmen: number;
    wingA: number;
    wingFireT: number;
    mineLv: number;
    mineT: number;
    laserLv: number;
    laserT: number;
    armor: number;
    critChance: number;
    critMult: number;
    reactiveLv: number;
    regen: number;
    xpMult: number;
    scrapMult: number;
    enemySpdBonus: number;
    empCd: number;
    empRad: number;
    walkPhase: number;
    recoil: number;
    evos: Record<string, boolean>;
}

export interface CardDef {
    id: string;
    cat: CardCategory;
    icon: string;
    maxLv?: number;
    noSlot?: boolean;
    rarityScalable?: boolean;
    pt: [string, string];
    en: [string, string];
    fn: (p: PlayerStats, mult: number, ctx?: CardApplyContext) => void;
}

export interface CardApplyContext {
    awardScrap?: (base: number, x: number, y: number, showFloat?: boolean) => void;
    triggerOvercharge?: (sec: number) => void;
    resetEmp?: () => void;
}

export interface EvoDef {
    id: string;
    weapon: string;
    wMin: number;
    passive: string | null;
    pMin: number;
    icon: string;
    pt: [string, string];
    en: [string, string];
    fn: (p: PlayerStats) => void;
}

export interface UpgradeChoice {
    isEvo: boolean;
    evo?: EvoDef;
    card?: CardDef;
    rarity: Rarity;
    mult: number;
}

export const CHASSIS_DATA: ChassisDef[] = [
    {
        id: 'interceptor', name: 'INTERCEPTOR', cost: 0, medalsReq: 0,
        hpMult: 1.0, dmgMult: 1.0, spdMult: 1.05, armor: 0, crit: 0.06, chain: 0, empMult: 1.0,
        descPt: 'Chassi ágil de reconhecimento. Equilíbrio perfeito entre velocidade e precisão.',
        descEn: 'Agile recon chassis. Balanced speed, handling, and precision firepower.',
        pal: { main: '#38bdf8', dark: '#1e3a8a', light: '#e0f2fe', visor: '#09151e', visorGlow: '#38d6f5', accent: '#7dd3fc' }
    },
    {
        id: 'guardiao', name: 'GUARDIÃO', cost: 240, medalsReq: 3,
        hpMult: 1.35, dmgMult: 1.05, spdMult: 0.94, armor: 0.14, crit: 0.04, chain: 0, empMult: 1.0,
        descPt: 'Blindagem pesada de aço-chumbo com núcleo térmico. +35% HP Máx e -14% Dano Recebido.',
        descEn: 'Heavy gunmetal armor with thermal core. +35% Max HP and -14% Damage Taken.',
        pal: { main: '#64748b', dark: '#1e293b', light: '#cbd5e1', visor: '#ff2a55', visorGlow: '#ff5c7c', accent: '#f97316' }
    },
    {
        id: 'tesla', name: 'TESLA', cost: 480, medalsReq: 7,
        hpMult: 1.05, dmgMult: 1.1, spdMult: 1.0, armor: 0.05, crit: 0.06, chain: 1, empMult: 0.85,
        descPt: 'Bobinas de alta tensão nos ombros. Inicia com Raio em Cadeia Lv1 e EMP 15% mais rápido.',
        descEn: 'High-voltage shoulder coils. Starts with Chain Lightning Lv1 and 15% faster EMP.',
        pal: { main: '#dc2626', dark: '#27272a', light: '#fca5a5', visor: '#2dd4bf', visorGlow: '#5eead4', accent: '#fbbf24' }
    },
    {
        id: 'sombra', name: 'SOMBRA', cost: 900, medalsReq: 12,
        hpMult: 0.9, dmgMult: 1.12, spdMult: 1.18, armor: 0, crit: 0.20, chain: 0, empMult: 0.95,
        descPt: 'Unidade furtiva de alta velocidade. +18% Velocidade, +20% Crítico e pós-imagem.',
        descEn: 'High-velocity stealth unit. +18% Speed, +20% Crit Chance, and ghost trails.',
        pal: { main: '#2563eb', dark: '#0f172a', light: '#dbeafe', visor: '#020617', visorGlow: '#60a5fa', accent: '#93c5fd' }
    }
];

export const LAB_UPGRADES: LabUpgradeDef[] = [
    { id: 'hull', namePt: 'Chapeamento do Chassi', nameEn: 'Chassis Plating', descPt: '+12 HP base por nível', descEn: '+12 Base HP per level', baseCost: 40, growth: 1.32, maxLv: 8 },
    { id: 'weapon', namePt: 'Núcleo Balístico', nameEn: 'Ballistic Core', descPt: '+8% Dano base por nível', descEn: '+8% Base Damage per level', baseCost: 45, growth: 1.32, maxLv: 8 },
    { id: 'capacitor', namePt: 'Capacitor de Disparo', nameEn: 'Fire Capacitor', descPt: '+5% Cadência por nível', descEn: '+5% Fire Rate per level', baseCost: 55, growth: 1.32, maxLv: 6 },
    { id: 'engine', namePt: 'Servomotores', nameEn: 'Servo Thrusters', descPt: '+5% Velocidade por nível', descEn: '+5% Move Speed per level', baseCost: 35, growth: 1.32, maxLv: 6 },
    { id: 'magnet', namePt: 'Bobina Magnética', nameEn: 'Magnet Coil', descPt: '+5px no raio de atração automática', descEn: '+5px automatic pickup radius', baseCost: 35, growth: 1.32, maxLv: 6 },
    { id: 'empCore', namePt: 'Reator EMP', nameEn: 'EMP Reactor', descPt: '-6% Recarga EMP e +16px raio', descEn: '-6% EMP Cooldown & +16px radius', baseCost: 60, growth: 1.32, maxLv: 5 },
    { id: 'salvage', namePt: 'Extrator de Sucata', nameEn: 'Scrap Harvester', descPt: '+10% Sucata obtida por nível', descEn: '+10% Scrap gained per level', baseCost: 45, growth: 1.32, maxLv: 5 }
];

export const ACHIEVEMENT_GOALS = {
    exterminador: [200, 1000, 3500, 10000, 25000],
    sobrevivente: [8, 14, 20, 28, 35],
    cacatanques: [15, 60, 180, 450, 1000],
    arsenal: [10, 16, 22, 28, 35]
};

export const RANKS = [
    { m: 0, min: 0, name: 'Recruta de Ferro', nameEn: 'Iron Recruit', lvl: 0, pct: 0 },
    { m: 3, min: 3, name: 'Soldado de Cromo', nameEn: 'Chrome Soldier', lvl: 1, pct: 8 },
    { m: 7, min: 7, name: 'Sargento de Aço', nameEn: 'Steel Sergeant', lvl: 2, pct: 16 },
    { m: 12, min: 12, name: 'Comandante de Elite', nameEn: 'Elite Commander', lvl: 3, pct: 24 },
    { m: 17, min: 17, name: 'Lenda da Arena', nameEn: 'Arena Legend', lvl: 4, pct: 35 }
];

export const MAX_MEDALS = 20;
export const GOLDEN_MEDALS = 17;

export function getChassis(id: string): ChassisDef {
    return CHASSIS_DATA.find(c => c.id === id) || CHASSIS_DATA[0];
}

export type PlayerSpriteKey = 'player' | 'player_guardiao' | 'player_tesla' | 'player_sombra';

export function getPlayerSpriteKey(chassisId: string): PlayerSpriteKey {
    if (chassisId === 'guardiao') return 'player_guardiao';
    if (chassisId === 'tesla') return 'player_tesla';
    if (chassisId === 'sombra') return 'player_sombra';
    return 'player';
}

export function totalMedalsFromAch(ach: Record<string, number>): number {
    return Object.entries(ACHIEVEMENT_GOALS).reduce((s, [id, goals]) => {
        return s + Math.min(ach[id] || 0, goals.length);
    }, 0);
}

export function rankForMedals(medals: number) {
    let r = RANKS[0];
    for (const x of RANKS) {
        if (medals >= x.m) r = x;
    }
    return r;
}

export function labCost(u: LabUpgradeDef, currentLv: number): number {
    return Math.round(u.baseCost * Math.pow(u.growth, currentLv || 0));
}

export function computeFixedBonus(hangar: Pick<HangarState, 'ach' | 'chassis' | 'lab'>) {
    const medals = totalMedalsFromAch(hangar.ach || {});
    const r = rankForMedals(medals);
    const k = 1 + r.pct / 100;
    const ch = getChassis(hangar.chassis);
    const lab = hangar.lab || {};
    const hp = Math.round((100 + (lab.hull || 0) * 12) * k * ch.hpMult);
    const dmg = Number(((10 * (1 + (lab.weapon || 0) * 0.08)) * k * ch.dmgMult).toFixed(1));
    const spd = Math.round(248 * (1 + (lab.engine || 0) * 0.05) * k * ch.spdMult);
    const rate = 0.42 / (k * (1 + (lab.capacitor || 0) * 0.05));
    const mag = Math.round(290 * 0.40 + (lab.magnet || 0) * 5);
    const empCd = Math.max(4.2, 8 * Math.pow(0.94, lab.empCore || 0) * ch.empMult);
    const empRad = 225 + (lab.empCore || 0) * 16;
    const scrapMult = 1 + (lab.salvage || 0) * 0.10;
    return { pct: r.pct, lvl: r.lvl, hp, dmg, spd, rate, mag, empCd, empRad, scrapMult, ch };
}

export interface EconomyTuning {
    enemyScrap: {
        drone: number;
        swarmDrone: number;
        gunner: number;
        tank: number;
        tankBounty: number;
        kamikaze: number;
        sniper: number;
        bastion: number;
        bastionBounty: number;
        artillery: number;
        miniboss: number;
        boss: number;
    };
    waveBonusFn: (completedWave: number) => number;
    supplyScrap: number;
    relayScrapFn: (wave: number) => number;
    supplyPodScrapFn: (wave: number) => number;
    scrapRewardScale: number;
}

export const ECONOMY_TUNING: EconomyTuning = {
    enemyScrap: {
        drone: 0.10,
        swarmDrone: 0.08,
        gunner: 0.30,
        tank: 0.80,
        tankBounty: 3.5,
        kamikaze: 0.28,
        sniper: 0.45,
        bastion: 0.95,
        bastionBounty: 4.5,
        artillery: 0.85,
        miniboss: 6,
        boss: 12
    },
    waveBonusFn: (w: number) => 3 + Math.min(4, Math.floor(Math.max(0, w - 1) * 0.22)),
    supplyScrap: 2,
    relayScrapFn: (w: number) => 3 + Math.min(4, Math.floor(w * 0.18)),
    supplyPodScrapFn: (w: number) => 4 + Math.min(4, Math.floor(w * 0.18)),
    // Calibrated from the reported 77 scrap in a 3:15 / wave-10 run.
    // A 1.75x economy factor targets roughly 135 scrap for a comparable run.
    scrapRewardScale: 1.70,
};

export const XP_CURVE = {
    // Mildly slower than the 1.5.0 curve, but restores the 1.6.0 XP reductions.
    // This keeps upgrade pacing useful without recreating the earlier XP snowball.
    initialMaxXp: 55,
    earlyGrowth: 1.12,
    lateGrowth: 1.12,
    earlyFlat: 18,
    lateFlat: 42,
    lateThresholdLv: 8,
    overflowCapRatio: 1.0,
    waveXpScale: 0.045,
    allowMultiLevel: true
};

export function nextMaxXp(currentMaxXp: number, newLv: number, curve = XP_CURVE): number {
    const late = newLv >= curve.lateThresholdLv;
    const mult = late ? curve.lateGrowth : curve.earlyGrowth;
    const flat = late ? curve.lateFlat : curve.earlyFlat;
    return Math.round(currentMaxXp * mult + flat);
}

export function applyXpGain(
    player: Pick<PlayerStats, 'xp' | 'maxXp' | 'lv'>,
    xpGain: number,
    curve = XP_CURVE
): number {
    player.xp += xpGain;
    let levelsGained = 0;
    if (curve.allowMultiLevel) {
        while (player.xp >= player.maxXp) {
            const overflow = player.xp - player.maxXp;
            player.lv++;
            player.maxXp = nextMaxXp(player.maxXp, player.lv, curve);
            player.xp = curve.overflowCapRatio >= 1
                ? overflow
                : Math.min(overflow, Math.floor(player.maxXp * curve.overflowCapRatio));
            levelsGained++;
        }
    } else if (player.xp >= player.maxXp) {
        const overflow = player.xp - player.maxXp;
        player.lv++;
        player.maxXp = nextMaxXp(player.maxXp, player.lv, curve);
        player.xp = curve.overflowCapRatio >= 1
            ? overflow
            : Math.min(overflow, Math.floor(player.maxXp * curve.overflowCapRatio));
        levelsGained = 1;
    }
    return levelsGained;
}

export const XP_REWARDS = {
    // Drones remain a small, frequent source of XP. Durable specialists are
    // deliberately worth much more so XP follows combat effort, not swarm size.
    commonDrone: 2,
    swarmDrone: 2,
    gunner: 10,
    kamikaze: 10,
    sniper: 12,
    tank: 20,
    bastion: 20,
    artillery: 18,
    miniboss: 65,
    boss: 95,
    relayCrystal: 8,
    supplyPodCrystal: 8
} as const;

export const ENEMY_BASE_HP = {
    gunner: 26,
    kamikaze: 21,
    sniper: 34,
    tank: 105,
    bastion: 68,
    artillery: 42,
    miniboss: 115
} as const;

export const ENEMY_BASE_DAMAGE = {
    drone: 7,
    gunner: 9,
    artillery: 10,
    bastion: 12,
    sniper: 14,
    miniboss: 14,
    kamikaze: 22,
    tank: 22
} as const;

export const ENEMY_DISPLAY_NAMES = {
    kamikaze: { pt: 'Kamikaze', en: 'Kamikaze' },
    bastion: { pt: 'Bastion', en: 'Bastion' },
    artillery: { pt: 'Arpoador', en: 'Harpooner' },
    miniboss: { pt: 'MiniBoss', en: 'MiniBoss' },
} as const;

export const PLAYER_BASE_HEIGHT = 56;
export const PLAYER_VISUAL_HEIGHT = Math.round(PLAYER_BASE_HEIGHT * 1.35);
export const MIN_PLAYER_SHOT_RANGE = Math.round(290 * 0.78);
export const KAMIKAZE_EXPLOSION_RADIUS = Math.round(290 * 0.5);

/** Kamikaze explosion damage radius is 50% of the player's current attack radius. */
export function getKamikazeExplosionRadius(playerRange: number): number {
    return Math.round(Math.max(MIN_PLAYER_SHOT_RANGE, playerRange) * 0.50);
}

/** Kamikaze starts its charge prep outside the player's current attack radius (+10%). */
export function getKamikazeChargeRange(playerRange: number): number {
    return Math.round(Math.max(MIN_PLAYER_SHOT_RANGE, playerRange) * 1.10);
}

export const BOSS_HP_MULTIPLIER = 1.50;
export const BOSS_SPRITE_DRAW_HEIGHT = 128;

export const BOSS_VARIANT_IDS = ['titan', 'phantom', 'siege', 'overlord'] as const;

/** Real Bosses use the 4 large Boss portraits; Kamikaze, Bastion, Arpoador (artillery)
 * and MiniBoss each use their own dedicated sprite assets rather than Boss sprites.
 */
export function getEnemySpriteKey(enemyType: string, bossVariant?: string): string | null {
    if (enemyType === 'boss') {
        const variant = BOSS_VARIANT_IDS.includes(bossVariant as typeof BOSS_VARIANT_IDS[number])
            ? bossVariant
            : 'titan';
        return `boss_${variant}`;
    }
    return ['drone', 'gunner', 'sniper', 'kamikaze', 'bastion', 'artillery', 'miniboss'].includes(enemyType)
        ? enemyType
        : null;
}

// World-space actor dimensions: player robot +35% (76 px), Kamikaze 81 px,
// Arpoador 73 px, Bastion 84 px, MiniBoss 84 px.
export const ENEMY_VISUAL_HEIGHTS = {
    drone: 34,
    gunner: 50,
    sniper: 50,
    kamikaze: Math.round(46 * 1.75),
    artillery: Math.round(PLAYER_BASE_HEIGHT * 1.30),
    bastion: Math.round(PLAYER_BASE_HEIGHT * 1.50),
    tank: Math.round(Math.round(PLAYER_BASE_HEIGHT * 1.42) * 1.40),
    miniboss: Math.round(PLAYER_BASE_HEIGHT * 1.50)
} as const;

/** Native Canvas silhouette fallback heights before world-space scaling. */
export const ENEMY_NATIVE_DRAW_HEIGHTS = {
    kamikaze: 42,
    bastion: 46,
    artillery: 44,
    miniboss: 62
} as const;

/** Scale factor that makes each dedicated vector fallback match its target world height. */
export function getEnemyVisualScale(enemyType: string): number {
    const nativeHeight = ENEMY_NATIVE_DRAW_HEIGHTS[enemyType as keyof typeof ENEMY_NATIVE_DRAW_HEIGHTS];
    const targetHeight = ENEMY_VISUAL_HEIGHTS[enemyType as keyof typeof ENEMY_VISUAL_HEIGHTS];
    if (!nativeHeight || !targetHeight) return 1;
    return targetHeight / nativeHeight;
}

export const CAMERA_TUNING = {
    desktopZoom: 0.92,
    tabletZoom: 0.84,
    mobileZoom: 0.74,
    playerVisualScale: Number((1.12 * 1.35).toFixed(3)),
    playerProjectileScale: 1.12,
    enemyProjectileScale: 1.38
} as const;

export function getCameraZoomForViewport(width: number, height: number): number {
    const minDim = Math.min(Math.max(1, width), Math.max(1, height));
    if (minDim < 520) return CAMERA_TUNING.mobileZoom;
    if (minDim < 900) return CAMERA_TUNING.tabletZoom;
    return CAMERA_TUNING.desktopZoom;
}

export function getWaveCaps(w: number) {
    const wave = Math.max(1, Math.floor(w));
    const hpMult = 1
        + (wave - 1) * 0.10
        + Math.max(0, wave - 5) * 0.055
        + Math.max(0, wave - 10) * 0.18
        + Math.max(0, wave - 16) * 0.24;
    const dmgMult = 1
        + (wave - 1) * 0.05
        + Math.max(0, wave - 10) * 0.04
        + Math.max(0, wave - 18) * 0.05;
    const maxEnemyBudget = wave <= 5
        ? 12 + (wave - 1) * 1.2
        : 16.8 + (wave - 5) * 0.9 + Math.max(0, wave - 10) * 1.1 + Math.max(0, wave - 16) * 0.3;
    const maxEnemies = Math.min(34, Math.round(maxEnemyBudget));
    return {
        maxEnemies,
        // Reserve space for specialists from wave 2 onward so drones cannot
        // occupy the entire active-enemy budget.
        maxDrones: wave <= 1 ? maxEnemies : Math.min(maxEnemies, Math.max(6, Math.round(maxEnemies * 0.45))),
        maxGunners: wave < 2 ? 0 : Math.min(6, 1 + Math.floor((wave - 2) / 2)),
        maxTanks: wave < 3 ? 0 : Math.min(5, 1 + Math.floor((wave - 3) / 4)),
        maxKamikazes: wave < 4 ? 0 : Math.min(5, 1 + Math.floor((wave - 4) / 3)),
        maxSnipers: wave < 5 ? 0 : Math.min(4, 1 + Math.floor((wave - 5) / 4)),
        maxBastions: wave < 7 ? 0 : Math.min(4, 1 + Math.floor((wave - 7) / 4)),
        maxArtillery: wave < 9 ? 0 : Math.min(4, 1 + Math.floor((wave - 9) / 4)),
        gunnerIntervalSec: 4.6,
        tankIntervalSec: 6.1,
        kamikazeIntervalSec: 6.6,
        sniperIntervalSec: 7.0,
        bastionIntervalSec: 7.5,
        artilleryIntervalSec: 8.2,
        dronesPerSec: Math.min(1.7, 0.75 + (wave - 1) * 0.045),
        hpMult,
        dmgMult
    };
}
export function getStarterPicksCount(startWave: number): number {
    return startWave <= 1 ? 0 : 3 + Math.floor((startWave - 1) / 5);
}

export type ArenaEventId = 'relay' | 'supply_pod' | 'orbital_sweep' | 'ally_turret' | 'bounty' | 'swarm' | 'ion_storm' | 'miniboss' | 'bombardment' | 'invasion';

export function getWaveEventPool(w: number): ArenaEventId[] {
    const wave = Math.max(1, Math.floor(w));
    const pool: ArenaEventId[] = ['relay', 'supply_pod'];
    if (wave >= 5) pool.push('ally_turret');
    if (wave >= 8) pool.push('orbital_sweep');
    if (wave >= 9) pool.push('bounty');
    if (wave >= 10) pool.push('swarm');
    if (wave >= 11) pool.push('ion_storm');
    if (wave >= 12) pool.push('miniboss');
    if (wave >= 13) pool.push('bombardment');
    if (wave >= 15) pool.push('invasion');
    return pool;
}

export const CARDS: CardDef[] = [
    // WEAPONS (max 4 slots)
    { id: 'TIRO EM LEQUE', cat: 'weapon', icon: '🔱', maxLv: 2, pt: ['TIRO EM LEQUE', '+2 projéteis em leque'], en: ['SPREAD SHOT', '+2 spread shots'],
      fn: (p) => { p.spreadLv = Math.min(2, p.spreadLv + 1); } },
    { id: 'ESCUDO ORBITAL', cat: 'weapon', icon: '🌀', maxLv: 3, pt: ['ESCUDO ORBITAL', '+1 esfera giratória defensiva'], en: ['ORBITAL SHIELD', '+1 defensive orbiting sphere'],
      fn: (p) => { p.orbits = Math.min(3, p.orbits + 1); } },
    { id: 'RAIO EM CADEIA', cat: 'weapon', icon: '⚡', maxLv: 3, pt: ['RAIO EM CADEIA', 'Arcos elétricos saltam no disparo principal'], en: ['CHAIN LIGHTNING', 'Primary shots arc between foes'],
      fn: (p) => { p.chain = Math.min(3, p.chain + 1); } },
    { id: 'MÍSSEIS TELEGUIADOS', cat: 'weapon', icon: '🚀', maxLv: 3, pt: ['MÍSSEIS TELEGUIADOS', 'Dispara foguetes teleguiados'], en: ['HOMING MISSILES', 'Fires seeking micro-missiles'],
      fn: (p) => { p.missiles = Math.min(3, p.missiles + 1); } },
    { id: 'MINI-DRONE ALIADO', cat: 'weapon', icon: '🛸', maxLv: 3, pt: ['MINI-DRONE ALIADO', 'Drone companheiro dá suporte próximo'], en: ['WINGMAN DRONE', 'Allied drone gives close fire support'],
      fn: (p) => { p.wingmen = Math.min(3, p.wingmen + 1); } },
    { id: 'MINAS DE PROXIMIDADE', cat: 'weapon', icon: '💣', maxLv: 3, pt: ['MINAS DE PROXIMIDADE', 'Solta minas explosivas ao correr'], en: ['PROXIMITY MINES', 'Drops explosive mines while moving'],
      fn: (p) => { p.mineLv = Math.min(3, p.mineLv + 1); } },
    { id: 'LANÇA-LASER', cat: 'weapon', icon: '🔦', maxLv: 3, pt: ['LANÇA-LASER', 'Feixe perfurante periódico de alta energia'], en: ['LASER LANCE', 'Periodic piercing energy beam'],
      fn: (p) => { p.laserLv = Math.min(3, p.laserLv + 1); } },

    // RECOVERY (no passive slot consumed; guaranteed in critical condition)
    { id: 'REPARO', cat: 'passive', noSlot: true, icon: '➕', pt: ['REPARO DE EMERGÊNCIA', 'Recupera 30% do HP máximo'], en: ['EMERGENCY REPAIR', 'Restores 30% of maximum HP'],
      fn: (p) => { p.hp = Math.min(p.maxHp, p.hp + Math.max(24, Math.round(p.maxHp * 0.30))); } },

    // PASSIVES (max 4 slots)
    { id: 'ARMA PESADA', cat: 'passive', icon: '💥', maxLv: 5, rarityScalable: true, pt: ['ARMA PESADA', '+10% de dano'], en: ['HEAVY WEAPON', '+10% damage'],
      fn: (p, m) => { p.dmg *= (1 + 0.10 * m); } },
    { id: 'CADÊNCIA', cat: 'passive', icon: '🔥', maxLv: 5, rarityScalable: true, pt: ['CADÊNCIA', '+12% velocidade de disparo'], en: ['FIRE RATE', '+12% fire rate'],
      fn: (p, m) => { p.baseRate = Math.max(0.16, p.baseRate / (1 + 0.12 * m)); } },
    { id: 'VELOCIDADE', cat: 'passive', icon: '💨', maxLv: 4, rarityScalable: true, pt: ['VELOCIDADE', '+9% velocidade de movimento'], en: ['THRUSTERS', '+9% move speed'],
      fn: (p, m) => { p.spd *= (1 + 0.09 * m); } },
    { id: 'HP MÁXIMO', cat: 'passive', icon: '🛡️', maxLv: 4, rarityScalable: true, pt: ['HP MÁXIMO', '+20% HP máximo'], en: ['MAX HP', '+20% max HP'],
      fn: (p, m) => { const add = Math.round(p.maxHp * 0.20 * m); p.maxHp += add; p.hp = Math.min(p.maxHp, p.hp + Math.round(add * 0.45)); } },
    { id: 'TIRO PERFURANTE', cat: 'passive', icon: '🏹', maxLv: 2, pt: ['TIRO PERFURANTE', '+1 inimigo atravessado'], en: ['PIERCING SHOT', '+1 enemy pierced'],
      fn: (p) => { p.pierce = Math.min(2, p.pierce + 1); } },
    { id: 'CAPACITOR EMP', cat: 'passive', icon: '🔋', maxLv: 3, pt: ['CAPACITOR EMP', '-12% recarga EMP e +18% raio'], en: ['EMP CAPACITOR', '-12% EMP CD & +18% radius'],
      fn: (p) => { p.empCd *= 0.88; p.empRad = Math.round(p.empRad * 1.18); } },
    { id: 'MIRAS CRÍTICAS', cat: 'passive', icon: '🎯', maxLv: 3, pt: ['MIRAS CRÍTICAS', '+8% chance crítica e +20% dano crít.'], en: ['CRITICAL OPTICS', '+8% crit chance & +20% crit dmg'],
      fn: (p) => { p.critChance = Math.min(0.50, p.critChance + 0.08); p.critMult += 0.20; } },
    { id: 'BLINDAGEM REATIVA', cat: 'passive', icon: '🧱', maxLv: 3, pt: ['COLETE À PROVA DE BALAS', '-10% de dano recebido por nível (máx. 30%)'], en: ['BULLETPROOF VEST', '-10% incoming damage per level (30% max)'],
      fn: (p) => { p.armor = Math.min(COMBAT_TUNING.armorCap, p.armor + 0.10); p.reactiveLv = Math.min(3, (p.reactiveLv || 0) + 1); } },
    { id: 'NANO-REGENERAÇÃO', cat: 'passive', icon: '🧬', maxLv: 3, pt: ['NANO-REGENERAÇÃO', '+0.50 HP/s contínuo'], en: ['NANO-REGEN', '+0.50 HP/s regeneration'],
      fn: (p) => { p.regen += 0.50; } },
    { id: 'CATALISADOR DE XP', cat: 'passive', icon: '💎', maxLv: 3, pt: ['CATALISADOR DE XP', '+10% XP e +12% Sucata'], en: ['XP CATALYST', '+10% XP & +12% Scrap'],
      fn: (p) => { p.xpMult += 0.10; p.scrapMult += 0.12; } },

    // TACTICAL TRADE-OFFS
    { id: 'CANHÃO DE VIDRO', cat: 'tactical', icon: '☢️', maxLv: 1, pt: ['+ FORÇA + VULNERÁVEL', '+30% Dano · -18% HP Máx'], en: ['+ POWER + VULNERABLE', '+30% Damage · -18% Max HP'],
      fn: (p) => { p.dmg *= 1.30; p.maxHp = Math.max(40, Math.round(p.maxHp * 0.82)); p.hp = Math.min(p.hp, p.maxHp); } },
    { id: 'FRENESI CURTO', cat: 'tactical', icon: '🔥', maxLv: 1, pt: ['TROCA: MENOR ALCANCE POR + TIROS POR SEGUNDO', '+24% tiros por segundo · -22% alcance. Atira mais rápido, mas exige chegar mais perto.'], en: ['TRADE-OFF: LESS RANGE FOR MORE SHOTS/SEC', '+24% shots per second · -22% range. Fires faster, but requires closer positioning.'],
      fn: (p) => { p.baseRate = Math.max(0.14, p.baseRate / 1.24); p.range = Math.round(p.range * 0.78); } },
    { id: 'PROTOCOLO SUCATEIRO', cat: 'tactical', icon: '🧲', maxLv: 1, pt: ['PROTOCOLO SUCATEIRO', '+25% Sucata e +20% XP · Inimigos +18% rápidos'], en: ['SALVAGE PROTOCOL', '+25% Scrap & +20% XP · Foes +18% faster'],
      fn: (p) => { p.scrapMult += 0.25; p.xpMult += 0.20; p.enemySpdBonus += 0.18; } },
    { id: 'SOBRECARGA NÚCLEO', cat: 'tactical', icon: '⚡', maxLv: 1, pt: ['SOBRECARGA DE NÚCLEO', '+18% Velocidade e +12% Crítico · -12% HP'], en: ['CORE OVERDRIVE', '+18% Speed & +12% Crit · -12% HP'],
      fn: (p) => { p.spd *= 1.18; p.critChance = Math.min(0.55, p.critChance + 0.12); p.maxHp = Math.max(40, Math.round(p.maxHp * 0.88)); p.hp = Math.min(p.hp, p.maxHp); } }
];

export const FALLBACK_CARDS: CardDef[] = [
    { id: 'SURTO_EMP', cat: 'passive', noSlot: true, icon: '⚡', pt: ['SURTO DE SOBRECARGA', 'Sobrecarga 5s + recarrega EMP'], en: ['OVERCHARGE SURGE', '5s Overcharge + resets EMP'],
      fn: (_p, _m, ctx) => { ctx?.triggerOvercharge?.(5); ctx?.resetEmp?.(); } },
    { id: 'RESERVA_SUCATA', cat: 'passive', noSlot: true, icon: '⚙️', pt: ['CÉLULA DE SUCATA', '+4 Sucata ⚙ e +10 HP'], en: ['SCRAP CELL', '+4 Scrap ⚙ & +10 HP'],
      fn: (p, _m, ctx) => { ctx?.awardScrap?.(4, p.x, p.y, true); p.hp = Math.min(p.maxHp, p.hp + 10); } },
    { id: 'AJUSTE_FINO', cat: 'passive', noSlot: true, maxLv: 8, icon: '🔧', pt: ['CALIBRAÇÃO FINA', '+3% Dano e +2% Velocidade'], en: ['FINE TUNING', '+3% Damage & +2% Move Speed'],
      fn: (p) => { p.dmg *= 1.03; p.spd *= 1.02; } }
];

export const EVOLUTIONS: EvoDef[] = [
    { id: 'EVO_PLASMA_STORM', weapon: 'TIRO EM LEQUE', wMin: 2, passive: 'CADÊNCIA', pMin: 1, icon: '🌟',
      pt: ['TEMPESTADE DE PLASMA', 'Rajada neon ampliada (+1 feixe, +12% cadência)'], en: ['PLASMA STORM', 'Expanded neon plasma volley (+1 beam, +12% rate)'],
      fn: (p) => { p.evos.plasmaStorm = true; p.baseRate = Math.max(0.13, p.baseRate * 0.89); p.dmg *= 1.10; } },
    { id: 'EVO_SINGULARITY', weapon: 'ESCUDO ORBITAL', wMin: 2, passive: null, pMin: 0, icon: '🪐',
      pt: ['SINGULARIDADE ORBITAL', '4 esferas amplificadas puxam cristais próximos'], en: ['ORBITAL SINGULARITY', '4 amplified orbs pull nearby crystals'],
      fn: (p) => { p.evos.singularity = true; p.orbits = Math.max(p.orbits, 4); } },
    { id: 'EVO_TESLA_COIL', weapon: 'RAIO EM CADEIA', wMin: 2, passive: 'ARMA PESADA', pMin: 1, icon: '🌩️',
      pt: ['BOBINA DE TESLA', '+1 salto elétrico e micro-atordoamento'], en: ['TESLA COIL', '+1 lightning jump & brief stun'],
      fn: (p) => { p.evos.teslaCoil = true; p.chain += 1; p.dmg *= 1.10; } },
    { id: 'EVO_THERMOBARIC', weapon: 'MÍSSEIS TELEGUIADOS', wMin: 2, passive: 'TIRO PERFURANTE', pMin: 1, icon: '☄️',
      pt: ['SALVA TERMOBÁRICA', 'Foguetes explodem em área de alto impacto'], en: ['THERMOBARIC SALVO', 'Rockets detonate in heavy AoE blasts'],
      fn: (p) => { p.evos.thermobaric = true; p.missiles = Math.min(4, p.missiles + 1); } },
    { id: 'EVO_GRAV_PULSE', weapon: 'CAPACITOR EMP', wMin: 2, passive: null, pMin: 0, icon: '🌌',
      pt: ['PULSO GRAVITACIONAL', 'EMP puxa cristais e eletrifica o chão por 3s'], en: ['GRAVITY PULSE', 'EMP pulls crystals & electrifies floor 3s'],
      fn: (p) => { p.evos.gravPulse = true; p.empRad = Math.round(p.empRad * 1.2); } }
];

export interface CombatTuning {
    playerInvTime: number;
    spreadSideScale: number;
    spreadFixCountBug: boolean;
    minFireRate: number;
    chainCooldown: number;
    chainMaxArcs: number;
    chainRadius: number;
    chainHopScale: number;
    chainHopDecay: number;
    wingmanDmgScale: number;
    wingmanCooldownBase: number;
    wingmanCooldownStep: number;
    wingmanCooldownMin: number;
    orbitTickCd: number;
    orbitDmgScale: number;
    armorCap: number;
}

export const COMBAT_TUNING: CombatTuning = {
    playerInvTime: 0.74,
    spreadSideScale: 0.50,
    spreadFixCountBug: true,
    minFireRate: 0.135,
    chainCooldown: 0.14,
    chainMaxArcs: 5,
    chainRadius: 190,
    chainHopScale: 0.50,
    chainHopDecay: 0.82,
    wingmanDmgScale: 0.72,
    wingmanCooldownBase: 0.72,
    wingmanCooldownStep: 0.08,
    wingmanCooldownMin: 0.45,
    orbitTickCd: 0.65,
    orbitDmgScale: 1.0,
    armorCap: 0.50
};

export function pickUpgradeChoices(params: {
    player: PlayerStats;
    upgradePicks: Record<string, number>;
    unlockedEvos: Record<string, boolean>;
    weaponSlotsUsed: Set<string>;
    passiveSlotsUsed: Set<string>;
    cards?: CardDef[];
    fallbackCards?: CardDef[];
    evos?: EvoDef[];
    rng?: () => number;
    forceRepair?: boolean;
}): UpgradeChoice[] {
    const {
        player, upgradePicks, unlockedEvos, weaponSlotsUsed, passiveSlotsUsed,
        cards = CARDS, fallbackCards = FALLBACK_CARDS, evos = EVOLUTIONS,
        rng = Math.random, forceRepair = false
    } = params;
    const shouldOfferRepair = forceRepair || player.hp <= player.maxHp * 0.60;

    const cardLv = (id: string) => upgradePicks[id] || 0;
    const readyEvos = evos.filter(ev => {
        if (unlockedEvos[ev.id]) return false;
        const wLv = cardLv(ev.weapon);
        const pLv = ev.passive ? cardLv(ev.passive) : 1;
        return wLv >= ev.wMin && pLv >= ev.pMin;
    });

    const pool = cards.filter(c => {
        if (c.id === 'REPARO' && !shouldOfferRepair) return false;
        if (c.maxLv && cardLv(c.id) >= c.maxLv) return false;
        if (c.cat === 'weapon' && !weaponSlotsUsed.has(c.id) && weaponSlotsUsed.size >= 4) return false;
        if (c.cat === 'passive' && !c.noSlot && !passiveSlotsUsed.has(c.id) && passiveSlotsUsed.size >= 4) return false;
        return true;
    });

    const makeChoice = (c: CardDef): UpgradeChoice => {
        let rarity: Rarity = 'common';
        let mult = 1;
        if (c.cat === 'tactical') {
            rarity = 'epic';
        } else if (c.rarityScalable) {
            const roll = rng();
            if (roll > 0.86) { rarity = 'epic'; mult = 1.75; }
            else if (roll > 0.58) { rarity = 'rare'; mult = 1.35; }
        }
        return { isEvo: false, card: c, rarity, mult };
    };

    const picked: UpgradeChoice[] = [];
    const chosenIds = new Set<string>();
    if (readyEvos.length > 0) {
        picked.push({ isEvo: true, evo: readyEvos[0], rarity: 'evo', mult: 1 });
    }

    const shuffled = [...pool];
    // Fisher–Yates avoids the bias of sort(() => random() - 0.5).
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    // Critical recovery is a real choice, not a rare fallback. It does not consume a passive slot.
    if (shouldOfferRepair) {
        const repairIndex = shuffled.findIndex(c => c.id === 'REPARO');
        if (repairIndex >= 0 && picked.length < 3) {
            const repair = shuffled.splice(repairIndex, 1)[0];
            picked.push(makeChoice(repair));
            chosenIds.add(repair.id);
        }
    }

    // Ensure early levels (Lv <= 4) offer at least 1 weapon option if available so builds start smoothly
    if (player.lv <= 4 && weaponSlotsUsed.size < 2 && picked.length < 3) {
        const wIdx = shuffled.findIndex(c => c.cat === 'weapon');
        if (wIdx !== -1) {
            const wc = shuffled.splice(wIdx, 1)[0];
            picked.push(makeChoice(wc));
            chosenIds.add(wc.id);
        }
    }

    let tacticalCount = 0;
    while (picked.length < 3 && shuffled.length > 0) {
        const c = shuffled.shift()!;
        if (chosenIds.has(c.id)) continue;
        // Limit to at most 1 tactical card per draw when non-tactical cards remain
        if (c.cat === 'tactical' && tacticalCount >= 1 && shuffled.some(x => x.cat !== 'tactical')) {
            continue;
        }
        if (c.cat === 'tactical') tacticalCount++;
        chosenIds.add(c.id);
        picked.push(makeChoice(c));
    }

    if (picked.length < 3) {
        const fbPool = [...fallbackCards]
            .filter(c => {
                if (c.id === 'REPARO' && !shouldOfferRepair) return false;
                if (c.maxLv && cardLv(c.id) >= c.maxLv) return false;
                return !chosenIds.has(c.id);
            })
            .sort(() => 0.5 - rng());
        while (picked.length < 3 && fbPool.length > 0) {
            const fc = fbPool.shift()!;
            chosenIds.add(fc.id);
            picked.push({ isEvo: false, card: fc, rarity: 'common', mult: 1 });
        }
    }

    // Fallback safety if player is full HP and all maxLv fallbacks exhausted
    if (picked.length < 3) {
        const anyFb = fallbackCards.filter(c => !chosenIds.has(c.id));
        while (picked.length < 3 && anyFb.length > 0) {
            const fc = anyFb.shift()!;
            chosenIds.add(fc.id);
            picked.push({ isEvo: false, card: fc, rarity: 'common', mult: 1 });
        }
    }

    return picked;
}
